
import Home from './pages/Home'
import es from './i18n/es'
import en from './i18n/en'
import MiniTaller from "./pages/MiniTaller";

<Route path="/minitaller" element={<MiniTaller />} />

const lang = navigator.language.startsWith('en') ? en : es

export default function App() {
  return <Home t={lang} />
}
