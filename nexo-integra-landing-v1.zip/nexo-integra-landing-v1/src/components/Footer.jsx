export default function Footer() {
  return (
    <footer className="footer">
      <p>
        Tu conocimiento tiene poder. Nosotros lo llevamos a su máxima expresión.
      </p>
      <p>© 2026 · Nexo Integra Systems</p>
    </footer>
  );
}
