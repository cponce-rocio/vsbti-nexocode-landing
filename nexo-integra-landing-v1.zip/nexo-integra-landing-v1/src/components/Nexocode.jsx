import nexo from "../assets/nexocode.png";

export default function Nexocode() {
  return (
    <section className="nexocode">
      <img src={nexo} alt="NexoCode" />
      <h2>No es solo código</h2>
      <p>Es el futuro que impulsa tu legado digital</p>
    </section>
  );
}
