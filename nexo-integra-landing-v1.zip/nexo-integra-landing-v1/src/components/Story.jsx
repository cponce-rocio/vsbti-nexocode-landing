export default function Story() {
  return (
    <section className="story">
      <h2>Tu conocimiento tiene poder</h2>
      <p>
        No importa si tu talento está dormido o si llevas años guardando tu propósito.
        Te ayudamos a transformarlo en un producto digital profesional que impacta,
        inspira y escala.
      </p>
    </section>
  );
}
