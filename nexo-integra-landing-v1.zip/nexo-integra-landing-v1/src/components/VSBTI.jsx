import flower from "../assets/vsbti.png";

export default function VSBTI() {
  return (
    <section style={{ textAlign: "center" }}>
      <img src={flower} alt="VSBTI" style={{ maxWidth: 260 }} />
      <h2>VSBTI · Transformación Consciente</h2>
      <p>
        Integramos propósito, conocimiento y conciencia para crear impacto real.
      </p>
    </section>
  );
}
