export const content = {
  ES: {
    eyebrow: "VSBTI & NEXOCODE · Servicio Next Level",
    heroTitle: "Tu talento merece brillar.",
    heroSpan: "Convierte tu conocimiento en un legado digital que cambia vidas",
    heroLead:
      "Aquí no solo estructuramos tu idea. La transformamos en un producto digital profesional, listo para impactar, inspirar y escalar globalmente. Te guiamos, te acompañamos y damos forma a tu visión.",
    heroCTA: "🌟 Empieza tu transformación ahora →",
  },

  EN: {
    eyebrow: "VSBTI & NEXOCODE · Next Level Service",
    heroTitle: "Your talent deserves to shine.",
    heroSpan: "Turn your knowledge into a digital legacy that changes lives",
    heroLead:
      "We don’t just structure your idea. We transform it into a professional digital product, ready to impact, inspire, and scale globally. We guide you, support you, and give form to your vision.",
    heroCTA: "🌟 Start your transformation now →",
  },
};
