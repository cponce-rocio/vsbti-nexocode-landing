
export default {
  heroTitle: "Your talent deserves to shine",
  heroSubtitle: "Turn your knowledge into a digital legacy that changes lives",
  heroCTA: "Start your transformation now",
  packsTitle: "Our Packs · Next Level",
  formTitle: "Let’s talk about your project",
  submit: "Send message"
}
