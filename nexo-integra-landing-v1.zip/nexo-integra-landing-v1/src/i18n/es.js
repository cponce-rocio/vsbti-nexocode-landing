
export default {
  heroTitle: "Tu talento merece brillar",
  heroSubtitle: "Convierte tu conocimiento en un legado digital que cambia vidas",
  heroCTA: "Empieza tu transformación ahora",
  packsTitle: "Nuestros Packs · Next Level",
  formTitle: "Hablemos de tu proyecto",
  submit: "Enviar mensaje"
}
