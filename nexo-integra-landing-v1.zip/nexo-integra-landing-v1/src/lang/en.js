const en = {
  hero: {
    eyebrow: "VSBTI & NEXOCODE · Next Level Service",
    title: "Your talent deserves to shine.",
    subtitle: "Turn your knowledge into a digital legacy that changes lives",
    text:
      "We don’t just structure ideas. We turn them into professional digital products ready to scale globally.",
    cta: {
      ig: "🌟 Activate your talent today →",
      ads: "🚀 Start your transformation now →",
      organic: "✨ Discover your next level →"
    }
  }
};

export default en;
