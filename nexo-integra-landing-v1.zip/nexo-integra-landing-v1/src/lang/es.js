const es = {
  hero: {
    eyebrow: "VSBTI & NEXOCODE · Servicio Next Level",
    title: "Tu talento merece brillar.",
    subtitle: "Convierte tu conocimiento en un legado digital que cambia vidas",
    text:
      "No solo estructuramos ideas. Creamos productos digitales profesionales listos para impactar, inspirar y escalar globalmente.",
    cta: {
      ig: "🌟 Activa tu talento hoy →",
      ads: "🚀 Empieza ahora tu transformación →",
      organic: "✨ Descubre tu siguiente nivel →"
    }
  }
};

export default es;
