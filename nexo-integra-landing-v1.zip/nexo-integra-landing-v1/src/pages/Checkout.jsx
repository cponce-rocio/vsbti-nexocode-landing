export default function Checkout() {
  return (
    <main className="checkout-page">
      <section className="section">
        <div className="container card center">

          <h1>Acceso inmediato al MiniTaller Exprés</h1>
          <p className="price">USD 997</p>

          <ul className="benefits">
            <li>Acceso inmediato</li>
            <li>Contenido grabado</li>
            <li>Garantía 7 días</li>
          </ul>

          <button className="btn-primary">
            💳 Finalizar compra
          </button>

          <p className="small">
            Pago seguro · Acceso inmediato · Soporte real
          </p>

        </div>
      </section>
    </main>
  );
}
