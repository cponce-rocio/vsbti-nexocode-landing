import { useEffect, useContext, useState } from "react";
import vsbti from "../assets/vsbti.png";
import "../styles/global.css";
import { LangContext } from "../context/LangContext";
import { useTrafficSource } from "../hooks/useTrafficSource";
import kitImg from "../packs/kit.png";

export default function Home() {
  const { t } = useContext(LangContext);
  const source = useTrafficSource();

  const [activePack, setActivePack] = useState(null);

  useEffect(() => {
    const elements = document.querySelectorAll(".reveal");

    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.15 }
    );

    elements.forEach(el => observer.observe(el));
  }, []);

  const scrollToPacks = () => {
    document.getElementById("packs-section")?.scrollIntoView({
      behavior: "smooth",
    });
  };

  const packDetails = {
    kit: {
      title: "Kit Activador de Talento Digital",
      description:
        "Convierte tu experiencia, talento o historia en tu primer producto digital profesional listo para vender.",
      includes: [
        "E-book Kindle profesional listo para publicar",
        "Cuaderno / Workbook editable",
        "Planner de 7 días orientado a acción",
        "Guía Ikigai + Escalera de Valor",
      ],
      investment: "USD 499 · EUR 499",
      action: "stripe",
      stripeUrl: "/checkout/kit-activador",
    },

    minitaller: {
      title: "MiniTaller Exprés Pro",
      description:
        "Transforma una idea o conocimiento en tu primer producto estructurado y operativo.",
      includes: [
        "MiniTaller Exprés estructurado",
        "Escalera de valor inicial",
        "Hosting del producto",
        "Estrategia orgánica básica",
      ],
      investment: "USD 997 · EUR 997",
      action: "stripe",
      stripeUrl: "/checkout/minitaller",
    },

    curso: {
      title: "Curso Profesional de Alto Nivel",
      description:
        "Ordena, profundiza y proyecta tu conocimiento en un curso profesional con impacto real.",
      includes: [
        "Curso completo estructurado",
        "Guía maestra + portada",
        "Cuaderno emocional",
        "Planner 7 días",
        "Landing page + Hosting",
      ],
      investment: "USD 1.997 · EUR 1.997",
      action: "stripe",
      stripeUrl: "/checkout/curso",
    },

    premium: {
      title: "Pack Premium · Sistema Completo",
      description:
        "Tu conocimiento funcionando como un sistema completo de impacto y monetización.",
      includes: [
        "E-book + Curso + MiniTaller",
        "Cuaderno emocional + Planner",
        "Escalera de valor completa",
        "Embudo evergreen orgánico",
        "Landing page profesional",
        "Hosting + Estrategia de monetización",
      ],
      investment: "USD 5.990 · EUR 5.990",
      action: "whatsapp",
    },

    estrella: {
      title: "Producto Estrella · Arquitectura Personalizada",
      description:
        "Diseñamos contigo un proyecto único, escalable y totalmente alineado a tu visión.",
      includes: [
        "Todos los productos del Pack Premium",
        "Arquitectura personalizada",
        "Acompañamiento estratégico",
        "Sistema escalable global",
      ],
      investment: "Desde USD 6.990",
      action: "whatsapp",
    },
  };

  return (
    <main>

      {/* HERO */}
      <section className="hero hero-premium">
        <div className="hero-glow"></div>

        <div className="container">
          <div className="hero-text reveal">
            <p className="eyebrow">{t.hero.eyebrow}</p>

            <h1>
              {t.hero.title}
              <span>{t.hero.subtitle}</span>
            </h1>

            <p className="lead">{t.hero.text}</p>

            <button className="btn-primary hero-cta">
              {t.hero.cta[source]}
            </button>
          </div>
        </div>
      </section>

      {/* INTRO */}
      <section className="section soft">
        <div className="container center reveal">
          <h2>
            Tu conocimiento tiene poder.<br />
            Nosotros lo llevamos a su máxima expresión.
          </h2>

          <p className="max">
            No importa si tu talento está dormido o si llevas años guardando tu
            propósito. Te ayudamos a darle forma, orden y estructura para
            convertirlo en impacto real.
          </p>

          <button className="btn-secondary" onClick={scrollToPacks}>
            🌟 Quiero que mi talento impacte →
          </button>
        </div>
      </section>

      {/* PACKS */}
      <section className="section" id="packs-section">
        <div className="container">
          <h2 className="center reveal">Inversión en tu Talento</h2>

          <div className="packs">

 {/* KIT */}
<div className="pack reveal">
  <h3 className="pack-title">Kit Activador de Talento Digital</h3>

  <div className="pack-image">
    <img src={kitImg} alt="Kit Activador" />
  </div>

  <div className="pack-content">
    <p className="impact">
      Tu primer producto digital profesional.
    </p>

    <button
      className="btn-primary small"
      onClick={() => setActivePack("kit")}
    >
      👉 Ver detalles
    </button>
  </div>
</div>



            <div className="pack reveal">
              <h3>MiniTaller Exprés Pro</h3>
              <p className="impact">
                De la idea a un producto real.
              </p>
              <button
                className="btn-primary small"
                onClick={() => setActivePack("minitaller")}
              >
                👉 Ver detalles
              </button>
            </div>

            <div className="pack reveal">
              <h3>Curso Profesional</h3>
              <p className="impact">
                Profundidad, orden y autoridad.
              </p>
              <button
                className="btn-primary small"
                onClick={() => setActivePack("curso")}
              >
                👉 Ver detalles
              </button>
            </div>

            <div className="pack reveal">
              <h3>Pack Premium · Sistema Completo</h3>
              <p className="impact">
                Tu conocimiento funcionando como sistema.
              </p>
              <button
                className="btn-primary"
                onClick={() => setActivePack("premium")}
              >
                👉 Ver detalles
              </button>
            </div>

            <div className="pack reveal">
              <h3>Producto Estrella · Arquitectura Personalizada</h3>
              <p className="impact">
                Cuando tu visión no cabe en un solo producto.
              </p>
              <button
                className="btn-primary"
                onClick={() => setActivePack("estrella")}
              >
                👉 Diseñar mi Producto Estrella
              </button>
            </div>

          </div>
        </div>
      </section>

      {/* MODAL */}
      {activePack && (
        <div className="modal-overlay" onClick={() => setActivePack(null)}>
          <div className="modal-card" onClick={e => e.stopPropagation()}>
            <h2>{packDetails[activePack].title}</h2>
            <p>{packDetails[activePack].description}</p>

            <ul>
              {packDetails[activePack].includes.map((item, i) => (
                <li key={i}>✔ {item}</li>
              ))}
            </ul>

            <p className="investment">
              <strong>Inversión en tu talento</strong><br />
              {packDetails[activePack].investment}
            </p>

            {packDetails[activePack].action === "stripe" ? (
              <a
                href={packDetails[activePack].stripeUrl}
                className="btn-primary"
              >
                💳 Continuar a pago
              </a>
            ) : (
              <a
                href="https://wa.me/549XXXXXXXXX"
                target="_blank"
                rel="noreferrer"
                className="btn-primary"
              >
                💬 Hablar por WhatsApp
              </a>
            )}

            <button
              className="btn-secondary small"
              onClick={() => setActivePack(null)}
            >
              Cerrar
            </button>
          </div>
        </div>
      )}

      {/* CIERRE */}
      <section className="section dark">
        <div className="container center reveal">
          <img src={vsbti} alt="VSBTI" className="logo" />
          <p className="max">
            Tu talento no es casual.<br />
            VSBTI × NEXOCODE te acompañan.
          </p>
        </div>
      </section>

    </main>
  );
}
