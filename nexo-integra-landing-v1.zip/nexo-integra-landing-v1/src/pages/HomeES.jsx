import { useEffect, useContext } from "react";
import vsbti from "../assets/vsbti.png";
import "../styles/global.css";
import { LangContext } from "../context/LangContext";
import { useTrafficSource } from "../hooks/useTrafficSource";

export default function Home() {
  const { t } = useContext(LangContext);
  const source = useTrafficSource();

  useEffect(() => {
    const elements = document.querySelectorAll(".reveal");

    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.15 }
    );

    elements.forEach(el => observer.observe(el));
  }, []);

  return (
    <main>

      {/* HERO */}
      <section className="hero hero-premium">
        <div className="hero-glow"></div>

        <div className="container">
          <div className="hero-text reveal">
            <p className="eyebrow">{t.hero.eyebrow}</p>

            <h1>
              {t.hero.title}
              <span>{t.hero.subtitle}</span>
            </h1>

            <p className="lead">{t.hero.text}</p>

            <button className="btn-primary hero-cta">
              {t.hero.cta[source]}
            </button>
          </div>
        </div>
      </section>

      {/* ACOMPAÑAMIENTO */}
      <section className="section soft">
        <div className="container center reveal">
          <h2>
            Tu conocimiento tiene poder.<br />
            Nosotros lo llevamos a su máxima expresión.
          </h2>

          <p className="max">
            No importa si tu talento está dormido o si llevas años guardando tu
            propósito. Te ayudamos a darle forma, orden y estructura para
            convertirlo en un producto que impacta, inspira y deja huella.
          </p>

          <ul className="benefits">
            <li>Mini-talleres exprés para empezar hoy</li>
            <li>Cursos completos para consolidar autoridad</li>
            <li>Libros profesionales que plasman tu legado</li>
            <li>Rutas de aprendizaje personalizadas</li>
            <li>Todo listo para publicar y escalar</li>
          </ul>

          <button className="btn-secondary">
            🌟 Quiero que mi talento impacte →
          </button>
        </div>
      </section>

      {/* PACKS */}
      <section className="section">
        <div className="container">
          <h2 className="center reveal">Nuestros Packs · Next Level</h2>

          <div className="packs">

            {/* PRODUCTO DE ENTRADA */}
            <div className="pack reveal">
              <h3>Kit Activador de Talento Digital</h3>
              <span>USD 499 · EUR 499</span>

              <p className="impact">
                Despierta tu conocimiento, convierte tu historia en un producto
                digital y empieza a generar impacto real.
              </p>

              <ul>
                <li>✔ E-book Kindle profesional listo para vender</li>
                <li>✔ Cuaderno / Workbook de acompañamiento</li>
                <li>✔ Planner de 7 días para acción inmediata</li>
                <li>✔ Guía Ikigai + Escalera de Valor</li>
              </ul>

              <p className="feel">
                Claridad, propósito y tu primer producto digital activo.
              </p>

              <button className="btn-primary small">
                👉 Quiero activar mi talento y crear mi primer producto digital
              </button>
            </div>

            {/* MINI TALLER */}
            <div className="pack reveal">
              <h3>MiniTaller Exprés</h3>
              <span>USD 997 · EUR 997</span>

              <p className="impact">
                Da vida a tu conocimiento y crea tu primer producto digital
                con claridad y acción inmediata.
              </p>

              <ul>
                <li>✔ MiniTaller estructurado</li>
                <li>✔ Escalera de valor inicial</li>
                <li>✔ Hosting incluido</li>
                <li>✔ Estrategia orgánica humana</li>
              </ul>

              <p className="feel">
                Claridad total. Dirección real. Primer paso firme.
              </p>

              <button className="btn-primary small">
                👉 Quiero activar mi primer producto
              </button>
            </div>

            {/* CURSO */}
            <div className="pack featured reveal">
              <h3>Curso Profesional de Alto Nivel</h3>
              <span>USD 1.997 · EUR 1.997</span>

              <p className="impact">
                Cuando tu conocimiento pide profundidad, orden y proyección.
              </p>

              <ul>
                <li>✔ Curso profesional completo</li>
                <li>✔ Guía maestra + portada</li>
                <li>✔ Cuaderno emocional + Planner</li>
                <li>✔ Landing + Hosting</li>
              </ul>

              <p className="feel">
                Autoridad real. Confianza interna. Coherencia total.
              </p>

              <button className="btn-primary small">
                👉 Quiero crear mi curso profesional
              </button>
            </div>

            {/* PREMIUM */}
            <div className="pack reveal">
              <h3>Pack Premium · Sistema Completo</h3>
              <span>USD 5.990 · EUR 5.990</span>

              <p className="impact">
                Tu conocimiento funcionando como un sistema,
                no como un esfuerzo aislado.
              </p>

              <ul>
                <li>✔ Curso + MiniTaller + Ebook</li>
                <li>✔ Embudo evergreen orgánico</li>
                <li>✔ Landing + Hosting</li>
                <li>✔ Estrategia profesional de monetización</li>
              </ul>

              <p className="feel">
                Impacto, orden y monetización consciente.
              </p>

              <button className="btn-primary small">
                👉 Quiero un sistema completo
              </button>
            </div>

            {/* PRODUCTO ESTRELLA */}
            <div className="pack full reveal">
              <h3>Producto Estrella · Arquitectura Personalizada</h3>
              <span>Desde USD 6.990 · EUR 6.990</span>

              <p className="impact">
                Cuando tu conocimiento es grande y tu visión no cabe
                en un solo producto.
              </p>

              <p>
                Diseñamos contigo una arquitectura única, escalable y alineada
                a tu vida, talento y propósito.
              </p>

              <button className="btn-primary">
                👉 Quiero diseñar mi arquitectura personalizada
              </button>
            </div>

          </div>
        </div>
      </section>

      {/* PASOS */}
      <section className="section soft">
        <div className="container center reveal">
          <h2>Tu camino al Next Level en 5 pasos claros</h2>

          <ol className="steps">
            <li>Descubrimiento de tu talento y visión</li>
            <li>Diseño de producto Next Level</li>
            <li>Producción de contenido profesional</li>
            <li>Optimización y coherencia total</li>
            <li>Publicación y entrega final</li>
          </ol>

          <button className="btn-secondary">
            🌟 Comienza tu transformación →
          </button>
        </div>
      </section>

      {/* CIERRE */}
      <section className="section dark">
        <div className="container center reveal">
          <img src={vsbti} alt="VSBTI" className="logo" />

          <p className="max">
            Tu talento no es casual. Tu conocimiento pide forma,
            orden y expansión.
            <br /><br />
            <strong>VSBTI & NEXOCODE te acompañan.</strong>
          </p>

          <button className="btn-primary">
            🌟 Activa tu legado ahora →
          </button>
        </div>
      </section>

    </main>
  );
}
