export default function Upsell() {
  return (
    <main className="section center">
      <h1>Potenciá tu resultado</h1>

      <p className="max">
        Sumá una sesión estratégica 1:1 para acelerar tu producto
        y evitar errores comunes.
      </p>

      <p className="price">USD 297</p>

      <button className="btn-primary">
        👉 Sí, quiero acelerar mi resultado
      </button>

      <button className="btn-secondary">
        No, continuar sin upsell
      </button>
    </main>
  );
}
