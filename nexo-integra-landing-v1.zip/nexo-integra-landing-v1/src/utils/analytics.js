export function track(event, data = {}) {
  console.log("📊 EVENT:", event, data);

  // Google Analytics / Meta / etc
  // gtag("event", event, data);
}
