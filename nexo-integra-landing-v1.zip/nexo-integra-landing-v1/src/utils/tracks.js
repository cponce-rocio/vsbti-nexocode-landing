export function track(event, data = {}) {
  console.log("TRACK:", event, data);
}
